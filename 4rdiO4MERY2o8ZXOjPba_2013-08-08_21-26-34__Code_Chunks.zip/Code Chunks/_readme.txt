Hey folks,

This folder of code chunks are for your reference
and to help you in your learning experience.

Please avoid just copying and pasting the code chunks
as it's better for you to learn how to hand-code
as much as you can at first.

But it's your learning experience, and you may do with
this code whatever you wish:)

Happy coding!
Brad